import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import pickle
import copy

k='f'+'d'

d = np.zeros(5)

a=np.array([1,2,3,4])
b=np.array([2,4,5,8])

print(None > 21)