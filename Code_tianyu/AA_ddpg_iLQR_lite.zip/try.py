import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import pickle
import copy

path_train_seqs_record = 'train_seqs_record.pkl'

fr = open(path_train_seqs_record, 'rb')
all_seqs_record = pickle.load(fr)
fr.close()

seq = all_seqs_record[102]
len_seq = len(seq)

seq_sas_ = []
for i in range(len_seq):
    step_tuple = seq[i]
    [s, a_noisy, _, s_, _] = step_tuple
    vec_sas_ = s.tolist() + a_noisy.tolist() + s_.tolist()
    dim_s = len(s.tolist())
    dim_a = len(a_noisy.tolist())
    seq_sas_.append(vec_sas_)

mean_sas_ = np.mean(seq_sas_, axis=0)
cov_sas_ = np.cov(np.array(seq_sas_).T)

mean_1 = mean_sas_[0:dim_s + dim_a]
mean_2 = mean_sas_[dim_s + dim_a:]

cov_11 = cov_sas_[0:dim_s + dim_a, 0:dim_s + dim_a]
cov_22 = cov_sas_[dim_s + dim_a:, dim_s + dim_a:]
cov_12 = cov_sas_[0:dim_s + dim_a, dim_s + dim_a:]
cov_21 = cov_sas_[dim_s + dim_a:, 0:dim_s + dim_a]

# s = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
# a = np.array([0, 0, 0, 0, 0, 0])

index = 19

s = np.array(seq_sas_[index][0:dim_s])
a = np.array(seq_sas_[index][dim_s:dim_s + dim_a])

s_ = np.array(seq_sas_[index + 1][0:dim_s])

x1 = s.tolist() + a.tolist()
x1 = np.array(x1)

mean_est = mean_2 + np.matmul(np.matmul(cov_21, np.linalg.inv(cov_11)), (x1 - mean_1))
cov_est = cov_22 - np.matmul(np.matmul(cov_21, np.linalg.inv(cov_11)), cov_12)

c = np.mat(np.random.rand(3, 3))
a = c * c.T
c = np.mat(np.random.rand(3, 3))
b = c * c.T
ia = a.I

b = np.mat([[4, 8], [6, 2]])
a = np.mat([[2, 0], [0, 2]])

c = [[1., 2.,3], [3., 4.,8], [3., 4.,8]]
c = np.mat(c)

d = np.array([2., 1.])

# k = np.matmul(c, d)

cc = np.mat(np.diag(c.diagonal().tolist()[0]))

print(cc**2)
